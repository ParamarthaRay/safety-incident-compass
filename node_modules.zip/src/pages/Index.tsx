
import { IncidentDashboard } from "@/components/IncidentDashboard";

const Index = () => {
  return (
    <div className="min-h-screen bg-gray-50">
      <IncidentDashboard />
    </div>
  );
};

export default Index;
