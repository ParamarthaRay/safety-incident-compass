

## Project info

**URL**: https://lovable.dev/projects/717c8ca6-6b86-4c9d-a178-b586db39bdce


## What technologies are used for this project?

This project is built with:

- Vite
- TypeScript
- React
- shadcn-ui
- Tailwind CSS


